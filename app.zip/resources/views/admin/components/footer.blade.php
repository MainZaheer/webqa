
  <footer class="main-footer">
    <strong>Copyright &copy; 2021-2021 <a href="#">webqa</a>.</strong> All rights reserved.
  </footer>